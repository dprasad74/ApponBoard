package sailpoint.plugin.helloworld.rest;

import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sailpoint.rest.plugin.BasePluginResource;
import sailpoint.rest.plugin.RequiredRight;
import sailpoint.rest.plugin.AllowAll;
import sailpoint.plugin.helloworld.rest.HelloWorldDTO;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.integration.ListResult;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;


@AllowAll
@Path("helloWorld")
public class HelloWorldResource extends BasePluginResource {
    public static final Log  log = LogFactory.getLog(HelloWorldResource.class);
    
    private SailPointContext context;

    @GET
    @Path("userName")
    @Produces(MediaType.APPLICATION_JSON)
    public sailpoint.integration.ListResult getGetUsers() {
        log.debug("GET getUsers");
        sailpoint.integration.ListResult ret = null;
       
        try {
            log.debug("Getting SailPointContext");
            context = SailPointFactory.getCurrentContext();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        List<HelloWorldDTO> listDTO = new ArrayList<>();

        try {
            HelloWorldDTO dto = new HelloWorldDTO();
            dto.setDisplayName(context.getUserName());
            listDTO.add(dto);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        int total = listDTO.size();
        log.debug("Size of return = " + total);
        return new ListResult(listDTO, total);
    }

    @GET
    @Path("test")
    @Produces(MediaType.APPLICATION_JSON)
    public String testConnection() {
        log.debug("GET test");
        String ret = "Success!";
        return ret;
    }

    @Override
    public String getPluginName() {
        return "helloworld";
    }
    


}
